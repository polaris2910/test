﻿// 변수 선언
bool guessCorrectly = false;
int strike;
int ball;
int attempt = 0;

// 정답 만들기
Random random = new Random();
int[] targetNumber =  new int[3];

for (int i = 0; i < targetNumber.Length; i++)
{
    targetNumber[i] = random.Next(1, 10);
}

// 본격 게임 시작
while (!guessCorrectly)
{
    // 변수 초기화
    strike = 0;
    ball = 0;
    attempt ++;

    // 사용자 답안 만들기
    Console.Write("Enter your guess (3 digits): ");

    int[] userGuess = new int[3];
    string guess = Console.ReadLine();

    for (int i = 0; i < userGuess.Length; i++)
    {
        userGuess[i] = int.Parse(guess[i].ToString());
    }

    // 답안 비교
    for (int i = 0; i < targetNumber.Length; i++)
    {
        if (userGuess[i] == targetNumber[i])
        {
            strike++;
        }
        else
        {
            for (int j = 0; j < targetNumber.Length; j++)
            {
                if (i != j && userGuess[i] == targetNumber[j])
                {
                    ball++;
                    break;
                }
            }
        }
    }

    // 비교 결과 출력
    Console.WriteLine($"{strike} Strike(s), {ball} Ball(s)");

    // guessCorrectly 참 판별
    if (strike == 3)
    {
        guessCorrectly = true;
    }
}

// 최종 답안 확인
if (guessCorrectly)
{
    Console.WriteLine($"Congratulations! You've guessed the number in {attempt} attempts.");
}